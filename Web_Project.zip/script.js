document.getElementById("contactForm").addEventListener("submit", function(e){
    e.preventDefault();

    document.getElementById("responseMsg").innerText =
        "Message sent successfully! (Demo only)";
});